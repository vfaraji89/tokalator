# Tokalator code maps 3.4.0

Requires Python 3.10+ and an existing project directory. No model API, account or network required for generation.

After extracting this archive, run:

```sh
python3 tokalator-context-3.4.0/bin/tokalator-install /path/to/project
cd /path/to/project
python3 scripts/tokalator-context.py .
python3 scripts/tokalator-context.py . --check
```

Creates GLOSSARY.md (declarations and documented purpose) and SITE-MAP.md (modules, imports, packages and filesystem routes). Source links and hashes aid inspection. Python uses AST; JS/TS extraction is heuristic. Dynamic imports, aliases and behavior may be incomplete. Verify source and tests.

The installer copies scripts/tokalator-context.py, merges .claude/settings.json and adds /code-review and /refresh-context commands. Existing unrelated hooks, permissions and commands are preserved. Reload Claude Code and inspect /hooks. SessionStart refreshes; review prompts refresh; Stop refreshes silently after a completed turn. User interrupts do not fire Stop. Other agents use the Python CLI explicitly.

Do not edit source during a scan. Refresh and check again if concurrent edits occur. --check exits 1 when the documents are missing or stale; it does not run code tests. Hidden paths, symlinks, dependencies, build outputs and files above 1 MB are skipped; ignored untracked files are excluded in Git projects.

To uninstall: remove hook entries referencing tokalator-context.py from .claude/settings.json, then remove only the installed Tokalator commands and script. Generated documents may be retained. Inspect existing files before deleting anything.

MIT license. See LICENSE. Source and generator tests included.
